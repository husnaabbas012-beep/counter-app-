import { useState } from 'react';

const initialValues = { name: '', email: '', message: '' };

function validate(values) {
  const errors = {};

  if (!values.name.trim()) {
    errors.name = 'Enter your name.';
  } else if (values.name.trim().length < 2) {
    errors.name = 'Name needs at least 2 characters.';
  }

  if (!values.email.trim()) {
    errors.email = 'Enter an email address.';
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email.trim())) {
    errors.email = 'That email address looks off.';
  }

  if (!values.message.trim()) {
    errors.message = 'Add a short message.';
  } else if (values.message.trim().length < 10) {
    errors.message = 'Message needs at least 10 characters.';
  }

  return errors;
}

function ContactForm() {
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    const nextValues = { ...values, [name]: value };
    setValues(nextValues);
    if (touched[name]) {
      setErrors(validate(nextValues));
    }
  };

  const handleBlur = (event) => {
    const { name } = event.target;
    setTouched((t) => ({ ...t, [name]: true }));
    setErrors(validate(values));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate(values);
    setErrors(validationErrors);
    setTouched({ name: true, email: true, message: true });

    if (Object.keys(validationErrors).length === 0) {
      setSubmitted(true);
    }
  };

  const handleReset = () => {
    setValues(initialValues);
    setErrors({});
    setTouched({});
    setSubmitted(false);
  };

  if (submitted) {
    return (
      <section className="panel form-panel" aria-labelledby="form-heading">
        <div className="panel-eyebrow">02 — Form handling</div>
        <h2 id="form-heading" className="panel-title">Sent</h2>
        <div className="success-note">
          <p>Thanks, {values.name.trim()}. Your message is in.</p>
          <p className="success-detail">A reply will go to {values.email.trim()}.</p>
        </div>
        <button type="button" className="btn btn-outline" onClick={handleReset}>
          Send another
        </button>
      </section>
    );
  }

  return (
    <section className="panel form-panel" aria-labelledby="form-heading">
      <div className="panel-eyebrow">02 — Form handling</div>
      <h2 id="form-heading" className="panel-title">Say something</h2>
      <p className="panel-hint">Validated on blur and on submit.</p>

      <form noValidate onSubmit={handleSubmit}>
        <div className="field">
          <label htmlFor="name">Name</label>
          <input
            id="name"
            name="name"
            type="text"
            value={values.name}
            onChange={handleChange}
            onBlur={handleBlur}
            aria-invalid={Boolean(touched.name && errors.name)}
            aria-describedby={touched.name && errors.name ? 'name-error' : undefined}
            placeholder="Ada Lovelace"
          />
          {touched.name && errors.name && (
            <p className="field-error" id="name-error">{errors.name}</p>
          )}
        </div>

        <div className="field">
          <label htmlFor="email">Email</label>
          <input
            id="email"
            name="email"
            type="email"
            value={values.email}
            onChange={handleChange}
            onBlur={handleBlur}
            aria-invalid={Boolean(touched.email && errors.email)}
            aria-describedby={touched.email && errors.email ? 'email-error' : undefined}
            placeholder="ada@example.com"
          />
          {touched.email && errors.email && (
            <p className="field-error" id="email-error">{errors.email}</p>
          )}
        </div>

        <div className="field">
          <label htmlFor="message">Message</label>
          <textarea
            id="message"
            name="message"
            rows={4}
            value={values.message}
            onChange={handleChange}
            onBlur={handleBlur}
            aria-invalid={Boolean(touched.message && errors.message)}
            aria-describedby={touched.message && errors.message ? 'message-error' : undefined}
            placeholder="What's this about?"
          />
          {touched.message && errors.message && (
            <p className="field-error" id="message-error">{errors.message}</p>
          )}
        </div>

        <div className="form-actions">
          <button type="button" className="btn btn-ghost" onClick={handleReset}>
            Clear
          </button>
          <button type="submit" className="btn btn-solid">
            Submit
          </button>
        </div>
      </form>
    </section>
  );
}

export default ContactForm;
