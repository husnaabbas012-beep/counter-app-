import Counter from './Counter';
import ContactForm from './ContactForm';
import './App.css';

function App() {
  return (
    <div className="page">
      <header className="page-header">
        <span className="page-mark">/demo</span>
        <h1 className="page-title">Counter &amp; Form Handling</h1>
        <p className="page-subtitle">
          A minimal React demo: one piece of state you click, one piece of state you type.
        </p>
      </header>

      <main className="grid">
        <Counter />
        <ContactForm />
      </main>

      <footer className="page-footer">Built with React + Vite</footer>
    </div>
  );
}

export default App;
