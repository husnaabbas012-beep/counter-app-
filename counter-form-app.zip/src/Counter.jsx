import { useState } from 'react';

const STEP = 1;

function Counter() {
  const [count, setCount] = useState(0);

  const decrement = () => setCount((c) => c - STEP);
  const increment = () => setCount((c) => c + STEP);
  const reset = () => setCount(0);

  return (
    <section className="panel counter-panel" aria-labelledby="counter-heading">
      <div className="panel-eyebrow">01 — Counter</div>
      <h2 id="counter-heading" className="panel-title">Tally</h2>
      <p className="panel-hint">Track anything you can click.</p>

      <div className="counter-display" aria-live="polite">
        <span className={`counter-value ${count < 0 ? 'is-negative' : ''}`}>{count}</span>
      </div>

      <div className="counter-controls">
        <button type="button" className="btn btn-outline" onClick={decrement} aria-label="Decrease count">
          −
        </button>
        <button type="button" className="btn btn-ghost" onClick={reset} aria-label="Reset count">
          Reset
        </button>
        <button type="button" className="btn btn-solid" onClick={increment} aria-label="Increase count">
          +
        </button>
      </div>
    </section>
  );
}

export default Counter;
