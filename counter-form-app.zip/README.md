# Counter & Form Handling Demo

A small React application built to demonstrate two core React fundamentals:
component state management (a counter) and controlled form handling with
validation (a contact form).

## Project Description

This app has two panels:

- **Counter** — increment, decrement, and reset a number using local
  component state (`useState`). The display updates live and turns red
  when the count goes negative.
- **Form handling** — a controlled contact form (name, email, message)
  that validates each field on blur and on submit, shows inline error
  messages, and displays a success confirmation once submitted
  successfully. A "Clear" button resets the form back to empty.

Built with [React](https://react.dev/) and [Vite](https://vitejs.dev/) —
no extra state or form libraries, so the logic is easy to read directly
in `src/Counter.jsx` and `src/ContactForm.jsx`.

## Installation Instructions

**Requirements:** Node.js 18+ and npm.

```bash
# 1. Clone the repository
git clone <your-repo-url>
cd counter-form-app

# 2. Install dependencies
npm install

# 3. Start the development server
npm run dev
```

The app will be available at `http://localhost:5173` (Vite will print
the exact URL in your terminal).

To create a production build:

```bash
npm run build
npm run preview   # serve the production build locally
```

## Usage Guidelines

### Counter panel
- Click **+** to increase the count.
- Click **−** to decrease the count (it can go negative).
- Click **Reset** to return the count to 0.

### Form panel
- Fill in **Name**, **Email**, and **Message**.
- Fields are validated as soon as you leave them (on blur):
  - Name: required, at least 2 characters.
  - Email: required, must look like a valid email address.
  - Message: required, at least 10 characters.
- Click **Submit** to validate all fields at once. If anything is
  invalid, an error message appears under that field and the form does
  not submit.
- On a valid submission, the form is replaced with a confirmation
  message. Click **Send another** to reset and fill it out again.
- Click **Clear** at any time to reset all fields and errors.

## Project Structure

```
counter-form-app/
├── src/
│   ├── App.jsx          # Page layout, renders Counter + ContactForm
│   ├── App.css           # App and component styling
│   ├── Counter.jsx       # Counter component (useState)
│   ├── ContactForm.jsx   # Controlled form with validation
│   ├── index.css         # Global styles and design tokens
│   └── main.jsx          # React entry point
├── index.html
└── package.json
```

## Tech Stack
- React 19
- Vite 8
- Plain CSS (no UI framework)
